from django.shortcuts import render
from django.http import HttpResponse
import psutil
import platform  
import cpuinfo
import GPUtil
from datetime import datetime

def configuration(request):
    try:
        # Memory Information
        MEMORY = psutil.virtual_memory()
        
        # Disk Information
        DISK_PART = psutil.disk_partitions()
        total_disk_space = 0
        total_used_space = 0
        total_free_space = 0
        for partition in DISK_PART:
            usage = psutil.disk_usage(partition.mountpoint)
            total_disk_space += usage.total
            total_used_space += usage.used
            total_free_space += usage.free

        # Disk I/O
        DISK_READ = psutil.disk_io_counters()

        # Battery Information
        BATTERY = psutil.sensors_battery()
        battery_time_hours = f'{BATTERY.secsleft / 3600:.2f}' if BATTERY and BATTERY.secsleft != psutil.POWER_TIME_UNLIMITED else 'N/A'
        
        # Boot Time
        BOOT = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
        
        # User Information
        USER = psutil.users()
        
        # Configuration Dictionary
        psutil_conf = {
            'MEMORY_PERCENT': f'{MEMORY.percent:.2f}',
            'MEMORY_AVAILABLE': f'{MEMORY.available / (1024 ** 3):.2f}',
            'MEMORY_USED': f'{MEMORY.used / (1024 ** 3):.2f}',
            'MEMORY_TOTAL': f'{MEMORY.total / (1024 ** 3):.2f}',
            'TOTAL_DISK_SPACE': f'{total_disk_space / (1024 ** 3):.2f}',
            'TOTAL_USED_SPACE': f'{total_used_space / (1024 ** 3):.2f}',
            'TOTAL_FREE_SPACE': f'{total_free_space / (1024 ** 3):.2f}',
            'DISK_PERCENT': f'{(total_used_space / total_disk_space) * 100:.2f}' if total_disk_space > 0 else 'N/A',
            'DISK_READ_SPEED': f'{DISK_READ.read_time / 1000:.2f}',
            'DISK_READ_BY': DISK_READ.read_bytes,
            'DISK_WRITE_SPEED': f'{DISK_READ.write_time / 1000:.2f}',
            'TOTAL_PARTITIONS': len(DISK_PART),  # Add this line
            'BATTERY_PERCENT': f'{BATTERY.percent:.2f}' if BATTERY else 'N/A',
            'BATTERY_TIME': battery_time_hours,
            'BATTERY_POWER': BATTERY.power_plugged if BATTERY else 'N/A',
            'BOOT_TIME': BOOT,
            'USER_NAME': USER[0].name if USER else 'N/A',
        }
        
        # Platform Information
        platform_conf = {
            'OS_NAME': platform.system(),
            'OS_VERSION': platform.platform(),
            'DEVICE_NAME': platform.node(),
            'BITS': platform.architecture()[0],
        }
        
        # CPU Information
        CPU_PERCENT = psutil.cpu_percent(1)
        CPU_CORE = psutil.cpu_count()
        cpu_info = cpuinfo.get_cpu_info()
        
        cpu_conf = {
            'CPU_PERCENT': f'{CPU_PERCENT:.2f}',
            'CORE': CPU_CORE,
            'CPU_NAME': cpu_info.get('brand_raw', 'N/A'),
            'CPU_HZ_ADV': cpu_info.get('hz_advertised_friendly', 'N/A'),
            'CPU_HZ_AC': cpu_info.get('hz_actual_friendly', 'N/A'),
        }
        
        # GPU Information
        gpus = GPUtil.getGPUs()
        gpu_conf = {}
        if gpus:
            gpu = gpus[0]
            gpu_conf = {
                'GPU_NAME': gpu.name,
                'GPU_LOAD_PERCENT': f'{gpu.load * 100:.2f}%',
                'GPU_USED': f'{gpu.memoryUsed}MB',
                'GPU_TOTAL': f'{gpu.memoryTotal}MB',
                'GPU_PERCENT': f'{gpu.memoryUtil * 100:.2f}%',
            }
        else:
            gpu_conf = {
                'GPU_NAME': 'N/A',
                'GPU_LOAD_PERCENT': 'N/A',
                'GPU_USED': 'N/A',
                'GPU_TOTAL': 'N/A',
                'GPU_PERCENT': 'N/A',
            }
        
        # Combine Configurations
        configuration = {
            'psutil_conf': psutil_conf,
            'platform_conf': platform_conf,
            'cpu_conf': cpu_conf,
            'gpu_conf': gpu_conf,
        }
        
        return render(request, "configuration.html", configuration)
    
    except Exception as e:
        return HttpResponse(f"An error occurred: {str(e)}")
